'use strict';

angular.module('navajoAngularApp')
  .controller('MainCtrl', function ($scope, $http) {

  });
