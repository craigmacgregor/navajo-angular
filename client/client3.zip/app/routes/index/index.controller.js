'use strict';

angular.module('navajoAngularApp')
  .controller('IndexCtrl', function ($scope, $http) {

  });
